package com.example.dartthrow;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onClick(View v)
    {
        EditText angle = findViewById(R.id.editText5);
        EditText velocity = findViewById(R.id.editText6);
        TextView result = findViewById(R.id.textView9);
        ImageView pic =findViewById(R.id.imageView2);

        try{

            Double A =0.0174533*Double.parseDouble(angle.getText().toString());

            Double V = Double.parseDouble(velocity.getText().toString());

            final Double D = 7.77;
            final int P = 6;
            final Double B = 17/3.0;
            final Double S = 1.0/48;
            Double Vx = 0.0,Vy = 0.0,T = 0.0,H = 0.0;
            Vx= V*(Math.cos(A));
            Vy=V*(Math.sin(A));
            T =D/Vx;
            H=P+(Vy*T)-((32*(T*T))/2);
            if(B+S>H&&B-S<H){
                result.setText("Hit bulls-eye");
                pic.setImageResource(R.drawable.welldone);
                result.setBackgroundColor(Color.rgb(10,200,100));
                if(V<0.0||V >50) {
                    result.setText("error velocity. Too long or negative ");
                    pic.setImageResource(R.drawable.loose);
                    result.setBackgroundColor(Color.rgb(210,88,80));}
                if (A<0||A>1) {
                    result.setText("error in Angle. Too large or negative");
                    pic.setImageResource(R.drawable.loose);
                    result.setBackgroundColor(Color.rgb(200,50,50));
                }

            }
            else {
                float calc;
                if(Math.abs(B+S-H)<=Math.abs(B-S-H))
                    calc=Math.abs((float)(B+S-H));

                else
                    calc=Math.abs((float)(B-S-H));

                if(calc>=0&&calc<5)
                    result.setBackgroundColor(Color.rgb(52,219,130));
                else if(calc>=5&&calc<10)
                    result.setBackgroundColor(Color.rgb(100,115,48));
                else if(calc>=10&&calc<15)
                    result.setBackgroundColor(Color.rgb(150,95,30));
                else
                    result.setBackgroundColor(Color.rgb(255,30,30));
                pic.setImageResource(R.drawable.loose);
                result.setText("Missed bulls-eye by " +calc + " feet");

                if(V<0.0||V >50) {
                    result.setText("error in velocity ");
                    result.setBackgroundColor(Color.rgb(255,100,100));
                }
                if (A<0||A>1) {
                    result.setText("error in Angle ");
                    result.setBackgroundColor(Color.rgb(255, 100, 100));
                }


            }


        }
        catch(NumberFormatException e){
            result.setText("Please Enter values");
        }
    }
    public void onGravityClick(View v)
    {
        EditText angle = findViewById(R.id.editText5);
        EditText velocity = findViewById(R.id.editText6);
        TextView result = findViewById(R.id.textView9);
        ImageView pic=findViewById(R.id.imageView2);

        try{
            Double A =0.0174533*Double.parseDouble(angle.getText().toString());
            Double V = Double.parseDouble(velocity.getText().toString());
            final Double D = 7.77;
            final int P = 6;
            final Double B = 17/3.0;
            final Double S = 1.0/48;
            Double Vx = 0.0,Vy = 0.0,T = 0.0,H = 0.0;
            Vx= V*(Math.cos(A));
            Vy=V*(Math.sin(A));
            T =D/Vx;
            H=P+(Vy*T)-(((32/6)*(T*T))/2);


            if(B+S>H&&B-S<H){
                result.setText("Hit bulls-eye");
                pic.setImageResource(R.drawable.welldone);
                result.setBackgroundColor(Color.rgb(64,255,120));

                if(V<0.0||V > 50) {
                    result.setText("velocity error");
                    pic.setImageResource(R.drawable.loose);
                    result.setBackgroundColor(Color.rgb(200,65,122));
                }
                if (A<0||A>1) {
                    result.setText("Angle error");
                    pic.setImageResource(R.drawable.loose);
                    result.setBackgroundColor(Color.rgb(255,255,255));
                }

            }
            else {
                float calc;
                if(Math.abs(B+S-H)<=Math.abs(B-S-H))
                    calc=Math.abs((float)(B+S-H));
                else
                    calc=Math.abs((float)(B-S-H));
                if(calc>=0&&calc<5)
                    result.setBackgroundColor(Color.rgb(52,219,130));
                else if(calc>=5&&calc<10)
                    result.setBackgroundColor(Color.rgb(100,180,81));
                else if(calc>=10&&calc<15)
                    result.setBackgroundColor(Color.rgb(152,100,81));
                else
                    result.setBackgroundColor(Color.rgb(255,0,0));
                pic.setImageResource(R.drawable.loose);
                result.setText("Missed bulls-eye by " + calc + " feet");
                if(V<0.0||V >50) {
                    result.setText("velocity error");
                    result.setBackgroundColor(Color.rgb(200,49,108));
                }
                if (A<0||A>1) {
                    result.setText("Angle error");
                    result.setBackgroundColor(Color.rgb(200, 49, 108));
                }
            }
        }
          catch(NumberFormatException e){
            result.setText("Please Enter values");
        }
    }
    public void Reset(View v) {
        EditText angle = findViewById(R.id.editText5);
         EditText velocity = findViewById(R.id.editText6);
         TextView result = findViewById(R.id.textView9);
        ImageView pic =findViewById(R.id.imageView2);
         angle.getText().clear();
        velocity.getText().clear();
        result.setText("Result");
         pic.setImageResource(R.drawable.ready);
        result.setBackgroundColor(0x00000000);
    }
}
